/**
 * com4j binding for stdole library.
 */
package com4j.stdole;