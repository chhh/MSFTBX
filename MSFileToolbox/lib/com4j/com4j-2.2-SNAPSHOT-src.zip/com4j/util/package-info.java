/**
 * misc. utility code.
 */
package com4j.util;