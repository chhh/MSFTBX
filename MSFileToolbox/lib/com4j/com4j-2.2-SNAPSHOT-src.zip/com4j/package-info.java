/**
 * com4j runtime.
 */
package com4j;